<?php
$con=mysqli_connect('localhost','root',"",'greengrocers');
if(!$con){
    die(mysqli_error($con));
}
?>