<div class="bg-success p-3 text-center"> 
<p> All rights reserved © Designed by Multiplex </p>
</div>